import org.jpos.iso.ISOComponent;
import org.jpos.iso.ISOException;
import org.jpos.iso.ISOFieldPackager;
import org.jpos.iso.ISOUtil;

import java.nio.charset.StandardCharsets;

public class Field002Packager extends ISOFieldPackager {

    public Field002Packager() {
        super();
    }

    public Field002Packager(int length, String description) {
        setLength(length);
        setDescription(description);
    }

    @Override
    public int getMaxPackedLength() {
        return getLength();
    }

    @Override
    public byte[] pack(ISOComponent c) throws ISOException {
        String pan = (String) c.getValue();
        if (pan == null || pan.length() > getLength()) {
            throw new ISOException("PAN is invalid or too long: " + pan);
        }
        return ISOUtil.hex2byte(ISOUtil.zeropad(pan, getLength()));
    }

    @Override
    public int unpack(ISOComponent c, byte[] b, int offset) throws ISOException {
        //30 35 length (05)
        //31 33 31 36 31 PAN (13161)


        // Step 1: Read ASCII-encoded length prefix ("05" = 5)
        int len = Integer.parseInt(new String(b, offset, 2, StandardCharsets.US_ASCII));

        // Step 2: Print raw bytes after length
        System.out.print("Field 2 raw bytes (hex): ");
        for (int i = offset + 2; i < offset + 2 + len; i++) {
            System.out.print(String.format("%02X ", b[i]));
        }
        System.out.println();

        // Step 3: Extract PAN from those bytes
        String pan = new String(b, offset + 2, len, StandardCharsets.US_ASCII);

        // Step 4: Mask last digit
        String masked = pan.length() > 1 ? pan.substring(0, pan.length() - 1) + "*" : "*";
        System.out.println("Final String: " + masked);

        // Step 5: Set value and return total bytes consumed
        c.setValue(masked);
        return 2 + len;  // 2 for prefix, len for PAN
    }




}

